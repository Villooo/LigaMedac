
package jugadores;



public class demarcacion {
    
   private String Demarcacion; 

    public String getDemarcacion() {
        return Demarcacion;
    }

    public void setDemarcacion(String Demarcacion) {
        this.Demarcacion = Demarcacion;
    }
    
   
   
   
    
}
